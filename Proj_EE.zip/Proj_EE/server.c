#define _GNU_SOURCE 
#include <sys/types.h>
#include <sys/socket.h>

#include "server.h"
#include "cache.h"
#include "pit.h"
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <netdb.h>
#include <errno.h>

void send_to_interface(const char *iface, const char *msg) {
    if (!iface || !msg) return;
    char ip[INET_ADDRSTRLEN], port[6];
    if (sscanf(iface, "%[^:]:%5s", ip, port) != 2) return;

    socket_t fd = connect_to_node(ip, port);
    if (fd >= 0) {
        send(fd, msg, strlen(msg), 0);
        close(fd);
    }
}

socket_t connect_to_node(const char *ip, const char *port) {
    struct addrinfo hints, *res;
    int err;
    socket_t fd;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM;

    err = getaddrinfo(ip, port, &hints, &res);
    if (err) { fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(err)); return -1; }

    fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0) { perror("socket"); freeaddrinfo(res); return -1; }

    if (connect(fd, res->ai_addr, res->ai_addrlen) < 0) {
        perror("connect"); close(fd); freeaddrinfo(res); return -1;
    }
    freeaddrinfo(res);
    return fd;
}

socket_t setup_tcp_server(NodeInfo *node) {
    socket_t sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) { perror("socket"); return -1; }

    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = htons(atoi(node->tcp_port))
    };

    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind"); close(sock); return -1;
    }
    if (listen(sock, 5) < 0) {
        perror("listen"); close(sock); return -1;
    }
    return sock;
}

void handle_tcp_message(socket_t conn, NodeInfo *node, TopologyState *topo) {
    char buf[512];
    ssize_t n = recv(conn, buf, sizeof(buf) - 1, 0);
    if (n <= 0) { close(conn); return; }
    buf[n] = 0;

    uint8_t id;
    char name[MAX_NAME_LEN];

    if (sscanf(buf, "INTEREST %hhu %100s", &id, name) == 2) {
        if (cache_contains(name)) {
            char obj[512];
            snprintf(obj, sizeof(obj), "OBJECT %d %s\n", id, name);
            send(conn, obj, strlen(obj), 0);
            return;
        }
        char tcp_iface[INET_ADDRSTRLEN + 6];
        snprintf(tcp_iface, sizeof(tcp_iface), "%s:%s", node->ip, node->tcp_port);
        id = pit_new_interest(name, tcp_iface);
        char interest[512];
        snprintf(interest, sizeof(interest), "INTEREST %d %s\n", id, name);
        for (int i = 0; i < topo->in_cnt; ++i) {
            send_to_interface(topo->internals[i], interest);
        }
        return;
    }

    if (sscanf(buf, "OBJECT %hhu %100s", &id, name) == 2) {
        cache_store(name);
        pit_hit(id, name);
        return;
    }

    if (sscanf(buf, "NOOBJECT %hhu %100s", &id, name) == 2) {
        pit_miss(id);
        return;
    }

    if (strncmp(buf, "ENTRY", 5) == 0) {
        char ip[INET_ADDRSTRLEN], port[6];
        if (sscanf(buf + 6, "%[^:]:%5s", ip, port) == 2) {
            char id[INET_ADDRSTRLEN + 6];
            snprintf(id, sizeof(id), "%s:%s", ip, port);
            topology_add_internal(topo, id);
            char safe[256];
            snprintf(safe, sizeof(safe), "SAFE %s:%s\n", node->ip, node->tcp_port);
            send(conn, safe, strlen(safe), 0);
        }
    } else if (strncmp(buf, "LEAVE", 5) == 0) {
        char ip[INET_ADDRSTRLEN], port[6];
        if (sscanf(buf + 6, "%[^:]:%5s", ip, port) == 2) {
            char id[INET_ADDRSTRLEN + 6];
            snprintf(id, sizeof(id), "%s:%s", ip, port);
            /* find and drop the sender */
            for (int i = 0; i < topo->in_cnt; ++i)
                if (!strcmp(topo->internals[i], id)) {
                    free(topo->internals[i]);
                    topo->internals[i] = topo->internals[--topo->in_cnt];
                    break;
                }
            /* reconnect logic */
            if (strcmp(ip, node->ip) || strcmp(port, node->tcp_port)) {
                /* this is NOT me → connect and set as external */
                topology_set_external(topo, strdup(id));
                socket_t fd = connect_to_node(ip, port);
                if (fd >= 0) {
                    char entry[128];
                    snprintf(entry, sizeof(entry), "ENTRY %s:%s\n", node->ip, node->tcp_port);
                    send(fd, entry, strlen(entry), 0);
                    close(fd);
                }
            } else {
                /* LEAVE is about me → pick any internal as new external */
                if (topo->in_cnt > 0) {
                    int pick = 0; /* arbitrary */
                    topology_set_external(topo, strdup(topo->internals[pick]));
                    socket_t fd = connect_to_node(topo->internals[pick], NULL);
                    if (fd >= 0) {
                        char entry[128];
                        snprintf(entry, sizeof(entry), "ENTRY %s:%s\n", node->ip, node->tcp_port);
                        send(fd, entry, strlen(entry), 0);
                        close(fd);
                    }
                } else {
                    topology_set_external(topo, NULL);
                }
            }
        }
    }
}

void open_external(const char *ip, const char *port) {
    socket_t fd = connect_to_node(ip, port);
    if (fd < 0) return;
    char buf[128];
    snprintf(buf, sizeof(buf), "ENTRY %s:%s\n", "127.0.0.1", "6000");
    send(fd, buf, strlen(buf), 0);
    close(fd);
}