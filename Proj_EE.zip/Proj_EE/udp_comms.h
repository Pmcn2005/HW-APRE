#ifndef UDP_COMMS_H
#define UDP_COMMS_H
#include "main.h"
#include "topology.h"
#ifdef _WIN32
    #include <winsock2.h>
#endif
void handle_udp_message(const char *msg, NodeInfo *node, TopologyState *topo);
void fetch_nodes_list(NodeInfo *node, const char *net, TopologyState *topo);
void store_udp_client(NodeInfo *node, struct sockaddr_in *addr, socklen_t len);
socket_t connect_to_node(const char *ip, const char *port);
#endif