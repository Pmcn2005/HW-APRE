#ifndef UTILS_H
#define UTILS_H

#include <stdbool.h>
bool is_valid_port(const char *port);
void print_error(const char *msg);

#endif