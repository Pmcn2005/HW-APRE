#define _GNU_SOURCE 
#ifdef __GNUC__
#define UNUSED __attribute__((unused))
#else
#define UNUSED
#endif

#include "topology.h"
#include "server.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void topology_init(TopologyState *t) {
    memset(t, 0, sizeof(*t));
    t->external_fd = -1;
}

void topology_cleanup(TopologyState *t) {
    free(t->external_neighbor);
    for (int i = 0; i < t->in_cnt; ++i) free(t->internals[i]);
    free(t->internals);
    memset(t, 0, sizeof(*t));
}

void topology_add_internal(TopologyState *t, const char *id) {
    t->internals = realloc(t->internals, (t->in_cnt + 1) * sizeof(char *));
    t->internals[t->in_cnt++] = strdup(id);
}

void topology_set_external(TopologyState *t, const char *id) {
    free(t->external_neighbor);
    t->external_neighbor = id ? strdup(id) : NULL;
}

static void send_leave(const char *to, const char *ext) {
    char ip[INET_ADDRSTRLEN], port[6];
    if (sscanf(to, "%[^:]:%5s", ip, port) != 2) return;
    socket_t fd = connect_to_node(ip, port);
    if (fd >= 0) {
        char buf[256];
        snprintf(buf, sizeof(buf), "LEAVE %s\n", ext);
        send(fd, buf, strlen(buf), 0);
        close(fd);
    }
}

void topology_leave(TopologyState *t, UNUSED NodeInfo *me) {
    /* inform every internal neighbor */
    const char *ext = t->external_neighbor ? t->external_neighbor : "";
    for (int i = 0; i < t->in_cnt; ++i)
        send_leave(t->internals[i], ext);
}