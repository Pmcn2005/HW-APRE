#ifndef PIT_H
#define PIT_H

#include <stdint.h>
#include <stdbool.h>

/* One-time init (thread-safe) */
void pit_init(void);

/* Register a new interest -> returns 8-bit id */
uint8_t pit_new_interest(const char *name, const char *iface);

/* Add another interface to an existing interest */
bool pit_add_face(uint8_t id, const char *iface);

/* Object found – forward OBJECT and delete PIT entry */
void pit_hit(uint8_t id, const char *data);

/* Object not found – forward NOOBJECT and delete PIT entry */
void pit_miss(uint8_t id);

/* Pretty-print PIT table (for show interest table) */
void pit_print(void);

#endif