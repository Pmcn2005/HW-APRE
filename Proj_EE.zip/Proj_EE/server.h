#ifndef SERVER_H
#define SERVER_H

#include "main.h"
#include "topology.h"

socket_t setup_tcp_server(NodeInfo *node);
socket_t connect_to_node(const char *ip, const char *port);
void send_to_interface(const char *iface, const char *msg);
void handle_tcp_message(socket_t conn, NodeInfo *node, TopologyState *topo);
void open_external(const char *ip, const char *port);

#endif