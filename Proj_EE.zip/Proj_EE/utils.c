#include "utils.h"
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

bool is_valid_port(const char *port)
{
    for (int i = 0; port[i]; i++)
        if (!isdigit((unsigned char)port[i])) return false;
    int p = atoi(port);
    return p > 1024 && p <= 65535;
}

void print_error(const char *msg)
{
    perror(msg);
}