#ifndef NDN_PROTOCOL_H
#define NDN_PROTOCOL_H

#include "topology.h"

void process_interest(const char *name, const char *incoming_iface, TopologyState *topo);
void process_object(const char *name, const char *data);
void print_interest_table(void);

#endif