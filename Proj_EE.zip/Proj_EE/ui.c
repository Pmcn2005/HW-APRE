#define _GNU_SOURCE
#include "ui.h"
#include "cache.h"
#include "topology.h"
#include "udp_comms.h"
#include "server.h"
#include <string.h>
#include <stdio.h>

void handle_command(char *input, NodeInfo *node, TopologyState *topo)
{
    char *nl = strchr(input, '\n'); if (nl) *nl = 0;

    char net[4], ip[INET_ADDRSTRLEN], port[6], name[MAX_NAME_LEN];

    if (sscanf(input, "join %3s", net) == 1 || sscanf(input, "j %3s", net) == 1) {
        fetch_nodes_list(node, net, topo);

    } else if (sscanf(input, "direct join %3s %15s %5s", net, ip, port) == 3) {
        if (!strcmp(ip, "0.0.0.0")) {
            topology_set_external(topo, NULL);
            return;
        }
        char id[INET_ADDRSTRLEN + 6];
        snprintf(id, sizeof(id), "%s:%s", ip, port);
        topology_set_external(topo, strdup(id));

        socket_t fd = connect_to_node(ip, port);
        if (fd < 0) { printf("connect failed\n"); return; }

        char buf[128];
        snprintf(buf, sizeof(buf), "ENTRY %s:%s\n", node->ip, node->tcp_port);
        send(fd, buf, strlen(buf), 0);
        close(fd);

    } else if (sscanf(input, "create %100s", name) == 1 || sscanf(input, "c %100s", name) == 1) {
        cache_store(name);

    } else if (sscanf(input, "delete %100s", name) == 1 || sscanf(input, "dl %100s", name) == 1) {
        cache_remove(name);

    } else if (sscanf(input, "retrieve %100s", name) == 1 || sscanf(input, "r %100s", name) == 1) {
        if (cache_contains(name))
            printf("Object \"%s\" found locally\n", name);
        else
            printf("Object \"%s\" NOT found locally\n", name);

    } else if (strncmp(input, "show topology", 13) == 0 || strncmp(input, "st", 2) == 0) {
        printf("External: %s\n", topo->external_neighbor ? topo->external_neighbor : "None");
        printf("Internals (%d):\n", topo->in_cnt);
        for (int i = 0; i < topo->in_cnt; ++i) printf("  %s\n", topo->internals[i]);

    } else if (strncmp(input, "show names", 10) == 0 || strncmp(input, "sn", 2) == 0) {
        cache_print(node->cache_size);

    } else if (strncmp(input, "leave", 5) == 0 || strncmp(input, "l", 1) == 0) {
        topology_leave(topo, node);

    } else if (strncmp(input, "exit", 4) == 0 || strncmp(input, "x", 1) == 0) {
        exit(0);

    } else if (strncmp(input, "help", 4) == 0) {
        printf("Commands: join <net>, direct join <net> <IP> <PORT>, create <name>, delete <name>, retrieve <name>, show topology, show names, leave, exit\n");
    } else {
        printf("Unknown command. Type 'help'\n");
    }
}