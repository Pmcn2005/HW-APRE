#include "main.h"
#include "cache.h"
#include "topology.h"
#include "server.h"
#include "udp_comms.h"
#include "ui.h"
#include "pit.h"

int main(int argc, char **argv)
{
    if (argc != 5) {
        fprintf(stderr,
                "Usage: %s IP TCP regIP regUDP\n"
                "Example: %s 127.0.0.1 5901 193.136.138.142 59000\n",
                argv[0], argv[0]);
        return EXIT_FAILURE;
    }

    NodeInfo *node = malloc(sizeof(NodeInfo));
    TopologyState *topo = malloc(sizeof(TopologyState));
    memset(node, 0, sizeof(NodeInfo));
    memset(topo, 0, sizeof(TopologyState));

    /* cache size is now fixed at 5 */
    node->cache_size = 5;
    strncpy(node->ip, argv[1], sizeof(node->ip) - 1);
    strncpy(node->tcp_port, argv[2], sizeof(node->tcp_port) - 1);
    strncpy(node->reg_ip, argv[3], sizeof(node->reg_ip) - 1);
    strncpy(node->reg_udp_port, argv[4], sizeof(node->reg_udp_port) - 1);

    node->tcp_fd = setup_tcp_server(node);
    if (node->tcp_fd < 0) exit(EXIT_FAILURE);

    node->udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (node->udp_fd < 0) { perror("UDP socket"); exit(EXIT_FAILURE); }

    struct sockaddr_in udp_addr = {
        .sin_family = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port = 0
    };
    if (bind(node->udp_fd, (struct sockaddr *)&udp_addr, sizeof(udp_addr)) < 0) {
        perror("UDP bind"); exit(EXIT_FAILURE);
    }

    socklen_t len = sizeof(udp_addr);
    getsockname(node->udp_fd, (struct sockaddr *)&udp_addr, &len);
    printf("UDP listening on port %d\n", ntohs(udp_addr.sin_port));

    /* Initialise cache and topology */
    cache_init(node->cache_size);
    topology_init(topo);

    fd_set rfds;
    int maxfd;
    struct timeval tv;

    while (1) {
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);
        FD_SET(node->tcp_fd, &rfds);
        FD_SET(node->udp_fd, &rfds);

        maxfd = MAX(MAX(node->tcp_fd, node->udp_fd), STDIN_FILENO);
        tv.tv_sec = 1; tv.tv_usec = 0;

        int ret = select(maxfd + 1, &rfds, NULL, NULL, &tv);
        if (ret < 0) { perror("select"); break; }

        if (FD_ISSET(STDIN_FILENO, &rfds)) {
            char buf[256];
            if (!fgets(buf, sizeof(buf), stdin)) break;
            handle_command(buf, node, topo);
        }
        if (FD_ISSET(node->tcp_fd, &rfds)) {
            struct sockaddr_in cli; socklen_t clen = sizeof(cli);
            socket_t conn = accept(node->tcp_fd, (struct sockaddr *)&cli, &clen);
            if (conn >= 0) { handle_tcp_message(conn, node, topo); close(conn); }
        }
        if (FD_ISSET(node->udp_fd, &rfds)) {
            struct sockaddr_in sender; socklen_t slen = sizeof(sender);
            char buf[2048];
            ssize_t n = recvfrom(node->udp_fd, buf, sizeof(buf) - 1, 0,
                                 (struct sockaddr *)&sender, &slen);
            if (n > 0) { buf[n] = 0; store_udp_client(node, &sender, slen);
                         handle_udp_message(buf, node, topo); }
        }
    }
    topology_cleanup(topo);
    return 0;
}