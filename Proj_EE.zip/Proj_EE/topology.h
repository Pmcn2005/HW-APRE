#ifndef TOPOLOGY_H
#define TOPOLOGY_H

#include "main.h"

#ifdef _WIN32
    #include <winsock2.h>
#endif

typedef struct {
    char *external_neighbor;
    char **internals;
    int in_cnt;
    int external_fd;
} TopologyState;

void topology_init(TopologyState *t);
void topology_cleanup(TopologyState *t);
void topology_add_internal(TopologyState *t, const char *id);
void topology_set_external(TopologyState *t, const char *id);
void topology_leave(TopologyState *t, NodeInfo *me);

#endif