#include "udp_comms.h"
#include "cache.h"
#include "pit.h"
#include "topology.h"
#include "server.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>

static void unreg(NodeInfo *node, const char *net) {
    struct sockaddr_in srv = {0};
    srv.sin_family = AF_INET;
    srv.sin_port   = htons(atoi(node->reg_udp_port));
    inet_pton(AF_INET, node->reg_ip, &srv.sin_addr);

    char buf[128];
    snprintf(buf, sizeof(buf), "UNREG %s %s %s\n",
             net, node->ip, node->tcp_port);
    sendto(node->udp_fd, buf, strlen(buf), 0,
           (struct sockaddr *)&srv, sizeof(srv));
}

void store_udp_client(NodeInfo *node, struct sockaddr_in *addr, socklen_t len)
{
    if (node->last_udp_client) free(node->last_udp_client);
    node->last_udp_client = malloc(len);
    memcpy(node->last_udp_client, addr, len);
    node->last_udp_client_len = len;
}

static void send_udp(NodeInfo *node, const char *msg)
{
    if (!node->last_udp_client) return;
    sendto(node->udp_fd, msg, strlen(msg), 0,
           (struct sockaddr *)node->last_udp_client,
           node->last_udp_client_len);
}

void fetch_nodes_list(NodeInfo *node, const char *net, TopologyState *topo)
{
    static struct sockaddr_in srv_addr;
    static socklen_t srv_len = 0;

    if (srv_len == 0) {
        srv_addr.sin_family = AF_INET;
        srv_addr.sin_port   = htons(atoi(node->reg_udp_port));
        inet_pton(AF_INET, node->reg_ip, &srv_addr.sin_addr);
        srv_len = sizeof(srv_addr);
    }

    char buf[2048];

    /* REG */
    char reg[128];
    snprintf(reg, sizeof(reg), "REG %s %s %s\n", net, node->ip, node->tcp_port);
    sendto(node->udp_fd, reg, strlen(reg), 0, (struct sockaddr *)&srv_addr, srv_len);
    recvfrom(node->udp_fd, buf, sizeof(buf) - 1, 0, NULL, NULL);

    /* NODES */
    snprintf(reg, sizeof(reg), "NODES %s\n", net);
    sendto(node->udp_fd, reg, strlen(reg), 0, (struct sockaddr *)&srv_addr, srv_len);
    ssize_t n = recvfrom(node->udp_fd, buf, sizeof(buf) - 1, 0, NULL, NULL);
    if (n <= 0) return;
    buf[n] = 0;

    if (strncmp(buf, "NODESLIST", 9)) return;
    char *line = strtok(buf + 9, "\n");
    while (line) {
        char ip[INET_ADDRSTRLEN], port[6];
        if (sscanf(line, "%15s %5s", ip, port) == 2) {
            char id[INET_ADDRSTRLEN + 6];
            snprintf(id, sizeof(id), "%s:%s", ip, port);
            if (strcmp(ip, node->ip) || strcmp(port, node->tcp_port)) {
                topology_add_internal(topo, id);
                socket_t fd = connect_to_node(ip, port);
                if (fd >= 0) {
                    char entry[128];
                    snprintf(entry, sizeof(entry), "ENTRY %s:%s\n", node->ip, node->tcp_port);
                    send(fd, entry, strlen(entry), 0);
                    close(fd);
                }
            }
        }
        line = strtok(NULL, "\n");
    }
}


/* --------------------------------------------
   handle_udp_message – ALL NDN message formats
   -------------------------------------------- */
void handle_udp_message(const char *msg, NodeInfo *node, TopologyState *topo)
{
    /* strip newline */
    char *nl = strchr(msg, '\n');
    if (nl) *nl = 0;

    char name[MAX_NAME_LEN];

    /* Incoming INTEREST / OBJECT / NOOBJECT  (TCP & UDP) */
    uint8_t id;
    if (sscanf(msg, "INTEREST %hhu %100s", &id, name) == 2) {
        /* cache hit? */
        if (cache_contains(name)) {
            char obj[512];
            snprintf(obj, sizeof(obj), "OBJECT %d %s\n", id, name);
            char local_iface[INET_ADDRSTRLEN + 6];
            snprintf(local_iface, sizeof(local_iface), "%s:%s", node->ip, node->tcp_port);
            send_to_interface(local_iface, obj);
            return;
        }
        /* else forward */
        char local_iface[INET_ADDRSTRLEN + 6];
        snprintf(local_iface, sizeof(local_iface), "%s:%s", node->ip, node->tcp_port);
        id = pit_new_interest(name, local_iface);
        char interest[512];
        snprintf(interest, sizeof(interest), "INTEREST %d %s\n", id, name);
        for (int i = 0; i < topo->in_cnt; i++)
            send_to_interface(topo->internals[i], interest);
        return;
    }

    if (sscanf(msg, "OBJECT %hhu %100s", &id, name) == 2) {
        cache_store(name);
        pit_hit(id, name);
        return;
    }

    if (sscanf(msg, "NOOBJECT %hhu %100s", &id, name) == 2) {
        pit_miss(id);
        return;
    }

    /* USER commands via UDP */
    else if (sscanf(msg, "create %100s", name) == 1 || sscanf(msg, "c %100s", name) == 1) {
        cache_store(name);
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Object created\n");
        send_udp(node, reply);

        /* broadcast OBJECT to internals */
        char obj[512];
        snprintf(obj, sizeof(obj), "OBJECT %d %s\n", 0, name);
        for (int i = 0; i < topo->in_cnt; ++i)
            send_to_interface(topo->internals[i], obj);

    } else if (sscanf(msg, "delete %100s", name) == 1 || sscanf(msg, "dl %100s", name) == 1) {
        cache_remove(name);
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Object deleted\n");
        send_udp(node, reply);

    } else if (sscanf(msg, "retrieve %100s", name) == 1 || sscanf(msg, "r %100s", name) == 1) {
        if (cache_contains(name)) {
            char reply[512];
            snprintf(reply, sizeof(reply), "OK: Object found locally\n");
            send_udp(node, reply);
        } else {
            char local_iface[INET_ADDRSTRLEN + 6];
            snprintf(local_iface, sizeof(local_iface), "%s:%s", node->ip, node->tcp_port);
            id = pit_new_interest(name, local_iface);
            char interest[512];
            snprintf(interest, sizeof(interest), "INTEREST %d %s\n", id, name);
            for (int i = 0; i < topo->in_cnt; i++)
                send_to_interface(topo->internals[i], interest);
            char reply[512];
            snprintf(reply, sizeof(reply), "OK: Interest propagated\n");
            send_udp(node, reply);
        }

    } else if (strncmp(msg, "show interest table", 19) == 0 || strncmp(msg, "si", 2) == 0) {
        pit_print();
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Interest table displayed\n");
        send_udp(node, reply);

    } else if (strncmp(msg, "show topology", 13) == 0 || strncmp(msg, "st", 2) == 0) {
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Topology displayed\n");
        send_udp(node, reply);
        printf("External: %s\n", topo->external_neighbor ? topo->external_neighbor : "None");
        printf("Internals (%d):\n", topo->in_cnt);
        for (int i = 0; i < topo->in_cnt; i++) printf("  %s\n", topo->internals[i]);

    } else if (strncmp(msg, "show names", 10) == 0 || strncmp(msg, "sn", 2) == 0) {
        cache_print(node->cache_size);
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Names displayed\n");
        send_udp(node, reply);

    }else if (strncmp(msg, "leave", 5) == 0 || strncmp(msg, "l", 1) == 0) {
        topology_leave(topo, node);
        unreg(node, "000");
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Left network\n");
        send_udp(node, reply);

    } else if (strncmp(msg, "exit", 4) == 0 || strncmp(msg, "x", 1) == 0) {
        char reply[512];
        snprintf(reply, sizeof(reply), "OK: Exiting\n");
        send_udp(node, reply);
        exit(0);
    }
}