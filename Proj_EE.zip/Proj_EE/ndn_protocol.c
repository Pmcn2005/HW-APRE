#ifdef __GNUC__
#define UNUSED __attribute__((unused))
#else
#define UNUSED
#endif

#include "ndn_protocol.h"
#include "cache.h"
#include "pit.h"
#include "server.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* --------------------------------------------------------------------------
   process_interest
-------------------------------------------------------------------------- */
void process_interest(const char *name, const char *incoming_iface, TopologyState *topo) {
    if (!name || !topo) return;

    /* 1. Cache hit? */
    if (cache_contains(name)) {
        char obj[512];
        snprintf(obj, sizeof(obj), "OBJECT 0 %s\n", name);
        send_to_interface(incoming_iface, obj);
        return;
    }

    /* 2. Forward INTEREST and record PIT */
    uint8_t id = pit_new_interest(name, incoming_iface);

    char msg[512];
    snprintf(msg, sizeof(msg), "INTEREST %d %s\n", id, name);
    for (int i = 0; i < topo->in_cnt; i++)
        if (strcmp(topo->internals[i], incoming_iface) != 0)
            send_to_interface(topo->internals[i], msg);
}

/* --------------------------------------------------------------------------
   process_object
-------------------------------------------------------------------------- */
void process_object(const char *name, UNUSED const char *data)
{
    if (!name) return;

    /* 1. Store in cache */
    cache_store(name);

    /* 2. Deliver to every face waiting for this name */
    pit_hit(0, name);          /* id is ignored in pit_hit when matching by name */
}

/* --------------------------------------------------------------------------
   print_interest_table  – delegated to pit module
-------------------------------------------------------------------------- */
void print_interest_table(void)
{
    pit_print();
}