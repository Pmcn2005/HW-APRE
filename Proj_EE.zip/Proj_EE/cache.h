#ifndef CACHE_H
#define CACHE_H
#include <stdbool.h>

void cache_init(int size);
bool cache_store(const char *name);
bool cache_contains(const char *name);
void cache_remove(const char *name);
void cache_clear(void);
void cache_print(int ignored);
#endif