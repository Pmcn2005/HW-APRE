/*
 * cache.c – LRU cache with dynamic size (true LRU list)
 */
#define _GNU_SOURCE

#include "cache.h"
#include "main.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>

#define UNUSED __attribute__((unused))

typedef struct CachedObject {
    char *name;
    struct CachedObject *prev, *next;
} CachedObject;

static CachedObject *head = NULL, *tail = NULL;   /* MRU … LRU */
static CachedObject **by_idx = NULL;              /* for O(1) eviction */
static int cap = 0, cnt = 0;
static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

static void lru_use(CachedObject *co) {
    if (co == head) return;

    /* unlink */
    if (co->prev) co->prev->next = co->next;
    if (co->next) co->next->prev = co->prev;
    if (co == tail) tail = co->prev;

    /* move to head (MRU) */
    co->prev = NULL;
    co->next = head;
    if (head) head->prev = co;
    head = co;
    if (!tail) tail = co;
}

void cache_init(int size) {
    pthread_mutex_lock(&mtx);
    cap = (size > MAX_CACHE_SIZE) ? MAX_CACHE_SIZE : size;
    by_idx = calloc(cap, sizeof(*by_idx));
    cnt = 0;
    head = tail = NULL;
    pthread_mutex_unlock(&mtx);
}

bool cache_store(const char *name) {
    if (!name) return false;
    pthread_mutex_lock(&mtx);

    /* already cached? just mark MRU */
    for (int i = 0; i < cnt; ++i)
        if (!strcmp(by_idx[i]->name, name)) {
            lru_use(by_idx[i]);
            pthread_mutex_unlock(&mtx);
            return true;
        }

    /* cache full? evict LRU (tail) */
    if (cnt == cap) {
        CachedObject *victim = tail;
        tail = tail->prev;
        if (tail) tail->next = NULL;
        else head = NULL;

        for (int i = 0; i < cnt; ++i)
            if (by_idx[i] == victim) {
                by_idx[i] = by_idx[--cnt];
                break;
            }
        free(victim->name);
        free(victim);
    }

    CachedObject *n = malloc(sizeof(*n));
    n->name = strdup(name);
    n->prev = n->next = NULL;
    lru_use(n);
    by_idx[cnt++] = n;

    pthread_mutex_unlock(&mtx);
    return true;
}

bool cache_contains(const char *name) {
    if (!name) return false;
    pthread_mutex_lock(&mtx);
    bool found = false;
    for (int i = 0; i < cnt; ++i)
        if (!strcmp(by_idx[i]->name, name)) {
            lru_use(by_idx[i]);
            found = true;
            break;
        }
    pthread_mutex_unlock(&mtx);
    return found;
}

void cache_remove(const char *name) {
    if (!name) return;
    pthread_mutex_lock(&mtx);
    for (int i = 0; i < cnt; ++i)
        if (!strcmp(by_idx[i]->name, name)) {
            CachedObject *co = by_idx[i];
            /* unlink from list */
            if (co->prev) co->prev->next = co->next;
            if (co->next) co->next->prev = co->prev;
            if (co == head) head = co->next;
            if (co == tail) tail = co->prev;

            free(co->name);
            free(co);
            by_idx[i] = by_idx[--cnt];
            break;
        }
    pthread_mutex_unlock(&mtx);
}

void cache_clear(void) {
    pthread_mutex_lock(&mtx);
    CachedObject *p = head;
    while (p) {
        CachedObject *next = p->next;
        free(p->name);
        free(p);
        p = next;
    }
    head = tail = NULL;
    cnt = 0;
    pthread_mutex_unlock(&mtx);
}

void cache_print(int ignored UNUSED) {
    pthread_mutex_lock(&mtx);
    printf("Cached objects (%d/%d):\n", cnt, cap);
    for (CachedObject *p = head; p; p = p->next)
        printf("  %s\n", p->name);
    pthread_mutex_unlock(&mtx);
}