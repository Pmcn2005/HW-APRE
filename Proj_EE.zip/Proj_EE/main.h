#ifndef MAIN_H
#define MAIN_H

#include <sys/select.h>
#include <sys/time.h> 

#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    typedef SOCKET socket_t;
    #define close closesocket
#else
    #include <sys/types.h>
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <unistd.h>
    typedef int socket_t;
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define INET_ADDRSTRLEN 16
#define MAX_NAME_LEN 100
#define MAX_CACHE_SIZE 5

typedef struct {
    char ip[INET_ADDRSTRLEN];
    char tcp_port[6];
    char reg_ip[INET_ADDRSTRLEN];
    char reg_udp_port[6];
    int  cache_size;

    socket_t tcp_fd;
    socket_t udp_fd;

    struct sockaddr_in *last_udp_client;
    socklen_t           last_udp_client_len;
} NodeInfo;

int setup_tcp_server(NodeInfo *n);
#endif