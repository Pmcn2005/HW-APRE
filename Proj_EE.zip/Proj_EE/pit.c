#define _GNU_SOURCE 

#include "pit.h"
#include "server.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <pthread.h>
#include <stdlib.h>

#define MAX_PIT 255

typedef struct Face {
    char *iface;
    struct Face *next;
} Face;

typedef struct {
    uint8_t id;
    char   *name;
    Face   *faces;
} PitEntry;

static PitEntry pit[MAX_PIT];
static int      pit_cnt = 0;
static pthread_mutex_t pit_mtx = PTHREAD_MUTEX_INITIALIZER;

void pit_init(void) {
    memset(pit, 0, sizeof(pit));
    pit_cnt = 0;
    srand((unsigned)time(NULL));
}

static PitEntry *find(uint8_t id) {
    for (int i = 0; i < pit_cnt; ++i)
        if (pit[i].id == id) return &pit[i];
    return NULL;
}

static PitEntry *find_by_name(const char *name) {
    for (int i = 0; i < pit_cnt; ++i)
        if (pit[i].name && !strcmp(pit[i].name, name)) return &pit[i];
    return NULL;
}

uint8_t pit_new_interest(const char *name, const char *iface) {
    if (!name || !iface) return 0;

    pthread_mutex_lock(&pit_mtx);

    /* reuse existing entry for same name */
    PitEntry *e = find_by_name(name);
    if (e) {
        Face *f = malloc(sizeof(*f));
        f->iface = strdup(iface);
        f->next  = e->faces;
        e->faces = f;
        pthread_mutex_unlock(&pit_mtx);
        return e->id;
    }

    if (pit_cnt == MAX_PIT) { pthread_mutex_unlock(&pit_mtx); return 0; }

    /* linear probe for free id */
    uint8_t id;
    do {
        id = (uint8_t)(rand() & 0xFF);
    } while (find(id));

    pit[pit_cnt].id   = id;
    pit[pit_cnt].name = strdup(name);
    pit[pit_cnt].faces = malloc(sizeof(Face));
    pit[pit_cnt].faces->iface = strdup(iface);
    pit[pit_cnt].faces->next  = NULL;
    pit_cnt++;

    pthread_mutex_unlock(&pit_mtx);
    return id;
}

bool pit_add_face(uint8_t id, const char *iface)
{
    PitEntry *e = find(id);
    if (!e) return false;
    Face *f = malloc(sizeof(*f));
    f->iface = strdup(iface);
    f->next  = e->faces;
    e->faces = f;
    return true;
}

static void send_to_iface(const char *iface, const char *msg)
{
    char ip[INET_ADDRSTRLEN], port[6];
    if (sscanf(iface, "%[^:]:%5s", ip, port) != 2) return;
    socket_t fd = connect_to_node(ip, port);
    if (fd >= 0) { send(fd, msg, strlen(msg), 0); close(fd); }
}

void pit_hit(uint8_t id, const char *data)
{
    pthread_mutex_lock(&pit_mtx);
    PitEntry *e = find(id);
    if (!e) { pthread_mutex_unlock(&pit_mtx); return; }

    char msg[512];
    snprintf(msg, sizeof(msg), "OBJECT %d %s\n", id, data);
    for (Face *f = e->faces; f; f = f->next) send_to_iface(f->iface, msg);

    /* free & remove */
    free(e->name);
    for (Face *f = e->faces; f; ) { Face *n = f->next; free(f->iface); free(f); f = n; }
    *e = pit[--pit_cnt];
    pthread_mutex_unlock(&pit_mtx);
}

void pit_miss(uint8_t id)
{
    pthread_mutex_lock(&pit_mtx);
    PitEntry *e = find(id);
    if (!e) { pthread_mutex_unlock(&pit_mtx); return; }

    char msg[512];
    snprintf(msg, sizeof(msg), "NOOBJECT %d %s\n", id, e->name);
    for (Face *f = e->faces; f; f = f->next) send_to_iface(f->iface, msg);

    /* free & remove */
    free(e->name);
    for (Face *f = e->faces; f; ) { Face *n = f->next; free(f->iface); free(f); f = n; }
    *e = pit[--pit_cnt];
    pthread_mutex_unlock(&pit_mtx);
}

void pit_print(void)
{
    pthread_mutex_lock(&pit_mtx);
    printf("=== Interest Table ===\n");
    for (int i = 0; i < pit_cnt; i++) {
        printf("Object: %s  id:%u\n", pit[i].name, pit[i].id);
        for (Face *f = pit[i].faces; f; f = f->next)
            printf("  Interface %s [WAITING]\n", f->iface);
    }
    printf("======================\n");
    pthread_mutex_unlock(&pit_mtx);
}