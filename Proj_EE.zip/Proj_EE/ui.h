#ifndef UI_H
#define UI_H
#include "main.h"
#include "topology.h"
void handle_command(char *input, NodeInfo *node, TopologyState *topo);
#endif